import streamlit as st
import joblib
import pandas as pd

model = joblib.load("final_random_forest_model.pkl")

st.title("Student Pass / Fail Prediction")
st.write("Enter student details below:")

avg_score = st.number_input(
    "Average Score (0 - 20)",
    min_value=0.0,
    max_value=20.0,
    key="avg_score"
)

studytime = st.number_input(
    "Study Time (1 - 4)",
    min_value=1,
    max_value=4,
    key="studytime"
)

absences = st.number_input(
    "Absences",
    min_value=0,
    key="absences"
)

study_effort = st.number_input(
    "Study Effort",
    key="study_effort"
)

if st.button("Predict"):
    input_data = pd.DataFrame({
        "avg_score": [avg_score],
        "studytime": [studytime],
        "absences": [absences],
        "study_effort": [study_effort]
    })

    prediction = model.predict(input_data)[0]

    if prediction == 1:
        st.success("Prediction: PASS ✅")
    else:
        st.error("Prediction: FAIL ❌")
